export const translations = {
  en: {
    // Navbar
    home: "Home",
    about: "About",
    skills: "Skills", 
    projects: "Projects",
    contact: "Contact",
    switchToArabic: "العربية",
    
    // Hero Section
    heroTitle: "VIZARD",
    heroSubtitle: "CREW IN BOUNTY",
    aboutMeBtn: "About Us",
    contactMeBtn: "Contact us",
    
    // About Section
    aboutTitle: "About Us",
    aboutSubtitle: "Learn more about our journey as a crew",
    aboutText1: "VIZARD is a bounty crew made up of skilled and dedicated members working together toward one goal.",
    aboutText2: "Our crew is built on teamwork, loyalty, and professionalism, creating a strong and welcoming community.",
    aboutText3: "I am NYX the lead developer for the team and the website. .",
    aboutText4: "Join VIZARD and become part of a crew that aims for the top.",
    yearsExperience: "Years of Experience",
    completedProjects: "Among the achievements",
    usersServed: "Users",
    linesOfCode: "help",
    
    // Skills Section
    skillsTitle: "Crew Skills",
    skillsSubtitle: "The strengths that make VIZARD stand out.",
    programmingLanguages: "Crew Abilities",
    tools: "Operations",
    languages: "The horse",
    arabic: "the first",
    english: "the second",
    lsDescription: "Strong leadership and crew management across all operations",
    twDescription: "Professional event organization and community coordination",
    stDescription: "Strategic planning and tactical decision-making for every mission",
    
    // Projects Section
    projectsTitle: "Crew Achievements",
    projectsSubtitle: "Our missions, events, and accomplishments",
    liveDemo: "View",
    code: "Details",
    
    // Contact Section
    contactTitle: "Join VIZARD",
    contactSubtitle: "Become part of our crew and start your journey with us.",
    sendMessage: "Apply Now or Send a Message",
    firstName: "First Name",
    lastName: "Last Name",
    email: "Discord User",
    subject: "Application Type",
    message: "Message",
    messagePlaceholder: "Tell us why you want join VIZARD...",
    sendBtn: "Send Application",
    findMeOnline: "Join or community",
    readyToWork: "Ready to Join VIZARD?",
    readyToWorkText: "We're always looking for loyal, active, and dedicated members to strengthen the VIZARD crew.",
    getInTouch: "Join now",
    
    // Footer
    footerText: "© 2025 VIZARD. All rights reserved."
  },
  ar: {
    // Navbar
    home: "الرئيسية",
    about: "نبذة عنا",
    skills: "مهاراتنا",
    projects: "مشاريعنا", 
    contact: "تواصل معنا",
    switchToArabic: "English",
    
    // Hero Section
    heroTitle: "فايزرد",
    heroSubtitle: "طاقم باونتي",
    aboutMeBtn: "نبذة عنا",
    contactMeBtn: "تواصل معنا",
    
    // About Section
    aboutTitle: "نبذة عنا",
    aboutSubtitle: "تعرف أكثر على رحلتنا",
    aboutText1: "فايزرد هو طاقم باونتي يضم نخبة من الأعضاء الذين يعملون معًا لتحقيق هدف واحد",
    aboutText2: "يعتمد الطاقم على التعاون والولاء والاحترافية لبناء مجتمع قوي ومميز",
    aboutText3: "أنا NYX المطور الرئيسي  للطاقم وللموقع .",
    aboutText4: "نسعى للتطور المستمر، وتنظيم الفعاليات، وتقديم أفضل تجربة لجميع الأعضاء،انضم إلى فايزرد وكن جزءًا من طاقم يسعى للوصول إلى القمة.",
    yearsExperience: "سنوات من الخبرة",
    completedProjects: "انجازات مكتملة",
    usersServed: "مستخدم",
    linesOfCode: "من المساعدة",
    
    // Skills Section
    skillsTitle: "مهارات الطاقم",
    skillsSubtitle: " نقاط القوة التي تميز طاقم فايزرد",
    programmingLanguages: "قدرات الطاقم",
    tools: "العمليات",
    languages: "الفروع",
    arabic: "الأول",
    english: "الثاني",
    jsDescription: " قيادة قوية وإدارة احترافية للطاقم في جميع المهام",
    cssDescription: "تنظيم الفعاليات والتنسيق بين أفراد المجتمع باحترافية.",
    tsDescription: "تخطيط استراتيجي واتخاذ القرارات المناسبة لكل مهمة.",
    
    // Projects Section
    projectsTitle: "انجازات الطاقم",
    projectsSubtitle: "أحدث الانجازات",
    liveDemo: "عرض مباشر",
    code: "انجازات",
    
    // Contact Section
    contactTitle: "تواصل معنا",
    contactSubtitle: "تواصل للانضمام لنا",
    sendMessage: "إرسال رسالة",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة",
    email: "اسم المستخدم في ديسكورد",
    subject: "نوع التقديم",
    message: "الرسالة",
    messagePlaceholder: "أخبرني عن سبب انضمامك...",
    sendBtn: "إرسال الرسالة",
    findMeOnline: "تواصل معنا عبر ديسكورد",
    readyToWork: "جاهز للانضمام لنا؟",
    readyToWorkText: "نرحب دائمًا بالأعضاء المخلصين والنشطين ليكونوا جزءًا من طاقم فايزرد.",
    getInTouch: "انضم لنا",
    
    // Footer
    footerText: "© 2025 فايزرد. جميع الحقوق محفوظة."
  }
};