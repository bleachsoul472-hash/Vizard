import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { translations } from "@/data/translations";

const SkillsSection = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const skillCategories = [
    {
      title: t.programmingLanguages,
      skills: [
        { name: "Leadership", level: 95 },
        { name: "Teamwork", level: 90 },
        { name: "Strategy", level: 92 },
        { name: "Discipline", level: 98 }
      ]
    },
    {
      title: t.tools,
      skills: [
        { name: "Operations.js", level: 97 },
        { name: "Event Management", level: 95 },
        { name: "Community Management", level: 95 },
        { name: "Mission Planning", level: 97 }
      ]
    },
    {
      title: t.languages,
      skills: [
        { name: t.arabic, level: 80 },
        { name: t.english, level: 60 }
      ]
    }
  ];

  const featuredSkills = [
    {
      name: "Leadership",
      description: t.lsDescription
    },
    {
      name: "Strategy",
      description: t.stDescription
    },
    {
      name: "Teamwork",
      description: t.twDescription
    }
  ];

  return (
    <section id="skills" className="py-20 px-6 bg-muted/20">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-text bg-clip-text text-transparent">
            {t.skillsTitle}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t.skillsSubtitle}
          </p>
        </div>

        {/* Skill Categories */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category) => (
            <Card key={category.title} className="bg-card border-border hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-6 text-center text-foreground">
                  {category.title}
                </h3>
                <div className="space-y-4">
                  {category.skills.map((skill) => (
                    <div key={skill.name}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-foreground">{skill.name}</span>
                        <span className="text-sm text-primary font-semibold">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-gradient-primary h-2 rounded-full transition-all duration-1000 ease-out"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Featured Skills */}
        <div className="grid md:grid-cols-3 gap-8">
          {featuredSkills.map((skill) => (
            <Card key={skill.name} className="bg-card border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-semibold mb-4 text-primary">{skill.name}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{skill.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;