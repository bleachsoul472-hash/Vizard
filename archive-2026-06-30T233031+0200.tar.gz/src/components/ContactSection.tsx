import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Youtube, Linkedin, Mail, Twitter, Send } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { translations } from "@/data/translations";

const ContactSection = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const socialLinks = [
    { icon: Youtube, label: "Discord", href: "https://discord.gg/6g45X9TYG" },
    { icon: Mail, label: "Email", href: "mailto:steg453@gmail.com" }
  ];

  return (
    <section id="contact" className="py-20 px-6 bg-muted/20">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-text bg-clip-text text-transparent">
            {t.contactTitle}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t.contactSubtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 text-foreground">{t.sendMessage}</h3>
              
              <form className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {t.firstName}
                    </label>
                    <Input 
                      placeholder={language === 'ar' ? 'شادو' : 'NYX'} 
                      className="bg-background border-border focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {t.lastName}
                    </label>
                    <Input 
                      placeholder={language === 'ar' ? 'NYX' : 'شادو'} 
                      className="bg-background border-border focus:border-primary"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t.email}
                  </label>
                  <Input 
                    type="text" 
                    placeholder={language === 'ar' ? '_v._i' : '_v._i'} 
                    className="bg-background border-border focus:border-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t.subject}
                  </label>
                  <Input 
                    placeholder={language === 'ar' ? 'سبب الانضمام ' : 'Reason for joining'} 
                    className="bg-background border-border focus:border-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t.message}
                  </label>
                  <Textarea 
                    placeholder={t.messagePlaceholder}
                    rows={6}
                    className="bg-background border-border focus:border-primary resize-none"
                  />
                </div>
                
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Send className="w-4 h-4 mr-2" />
                  {t.sendBtn}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="space-y-8">
            {/* Social Links */}
            <Card className="bg-card border-border">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold mb-6 text-foreground">{t.findMeOnline}</h3>
                <div className="grid grid-cols-2 gap-4">
                  {socialLinks.map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-4 rounded-lg bg-background hover:bg-primary/10 transition-colors group"
                    >
                      <social.icon className="w-6 h-6 text-primary" />
                      <span className="font-medium text-foreground">{social.label}</span>
                    </a>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Info */}
            <Card className="bg-primary text-primary-foreground">
              <CardContent className="p-8 text-center">
                <h3 className="text-xl font-semibold mb-4">{t.readyToWork}</h3>
                <p className="mb-6 opacity-90">
                  {t.readyToWorkText}
                </p>
                <Button 
                  variant="secondary" 
                  className="bg-white text-primary hover:bg-white/90"
                  asChild
                >
                  <a href="discord: https://discord.gg/6g45X9TYG">
                    <Mail className="w-4 h-4 mr-2" />
                    {t.getInTouch}
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;