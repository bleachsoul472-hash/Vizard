import { useLanguage } from "@/contexts/LanguageContext";
import { translations } from "@/data/translations";

const AboutSection = () => {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <section id="about" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-text bg-clip-text text-transparent">
            {t.aboutTitle}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t.aboutSubtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-6">
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                {t.aboutText1}
              </p>
              <p>
                {t.aboutText2}
              </p>
              <p>
                {t.aboutText3}
              </p>
              <p>
                {t.aboutText4}
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-6">
            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="text-4xl font-bold text-primary mb-2">3+</div>
              <div className="text-muted-foreground">{t.yearsExperience}</div>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="text-4xl font-bold text-primary mb-2">{language === 'ar' ? 'العديد' : 'Many'}</div>
              <div className="text-muted-foreground">{t.completedProjects}</div>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="text-4xl font-bold text-primary mb-2">10k+</div>
              <div className="text-muted-foreground">{t.usersServed}</div>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="text-4xl font-bold text-primary mb-2">∞</div>
              <div className="text-muted-foreground">{t.linesOfCode}</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;