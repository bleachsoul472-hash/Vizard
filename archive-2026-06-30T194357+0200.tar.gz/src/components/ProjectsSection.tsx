import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { translations } from "@/data/translations";

const ProjectsSection = () => {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <section id="projects" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-text bg-clip-text text-transparent">
            {t.projectsTitle}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t.projectsSubtitle}
          </p>
        </div>

        {/* Discord Server Card */}
        <div className="flex justify-center">
          <Card className="bg-card border-border hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:-translate-y-2 max-w-2xl w-full">
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  {language === 'ar' ? 'جميع مشاريعي الخاصة' : 'All My Projects'}
                </h3>
                <p className="text-muted-foreground text-lg">
                  {language === 'ar' ? 
                    'انضم إلى سيرفر الديسكورد الخاص بي لرؤية جميع مشاريعي والحصول على الدعم والمساعدة' : 
                    'Join my Discord server to see all my projects and get support and help'
                  }
                </p>
              </div>
              
              <Button 
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg font-medium"
                asChild
              >
                <a href="https://discord.gg/wicks" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-5 h-5 mr-2" />
                  {language === 'ar' ? 'انضم إلى سيرفر الديسكورد' : 'Join Discord Server'}
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;