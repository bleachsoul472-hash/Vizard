import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Calendar, Clock } from "lucide-react";

const ProgrammingSection = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A full-stack e-commerce solution built with React, Node.js, and PostgreSQL. Features include user authentication, payment processing, and admin dashboard.",
      tech: ["React", "Node.js", "PostgreSQL", "Stripe"],
      date: "2024",
      readTime: "5 min read",
      link: "#",
      github: "#"
    },
    {
      title: "Task Management App",
      description: "A collaborative task management application with real-time updates, drag-and-drop functionality, and team collaboration features.",
      tech: ["TypeScript", "React", "Socket.io", "MongoDB"],
      date: "2024",
      readTime: "4 min read",
      link: "#",
      github: "#"
    },
    {
      title: "API Rate Limiter",
      description: "A distributed rate limiting system for microservices architecture. Implements sliding window algorithm with Redis for high-performance scenarios.",
      tech: ["Go", "Redis", "Docker", "Kubernetes"],
      date: "2023",
      readTime: "7 min read",
      link: "#",
      github: "#"
    }
  ];

  const blogPosts = [
    {
      title: "Understanding React Server Components",
      description: "A deep dive into the new React Server Components, their benefits, and how to implement them in your next project.",
      date: "Dec 2024",
      readTime: "8 min read",
      tags: ["React", "Performance", "Web Development"]
    },
    {
      title: "Building Scalable APIs with Node.js",
      description: "Best practices for designing and implementing scalable REST APIs that can handle millions of requests.",
      date: "Nov 2024",
      readTime: "12 min read",
      tags: ["Node.js", "API Design", "Scalability"]
    },
    {
      title: "The Art of Code Reviews",
      description: "How to give and receive constructive code reviews that improve code quality and team collaboration.",
      date: "Oct 2024",
      readTime: "6 min read",
      tags: ["Best Practices", "Team Work", "Code Quality"]
    }
  ];

  return (
    <section className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            Programming & Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Here's a collection of projects I've built and technical articles I've written. 
            Each represents a learning journey and a step forward in my development career.
          </p>
        </div>

        {/* Projects */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold mb-8 text-foreground">Featured Projects</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <Card key={project.title} className="bg-gradient-card border-primary/10 hover:shadow-purple transition-all duration-300 hover:-translate-y-2 animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-foreground">{project.title}</CardTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {project.date}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {project.readTime}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-sm">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <Badge key={tech} variant="secondary" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <ExternalLink className="w-4 h-4 mr-1" />
                      Demo
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <Github className="w-4 h-4 mr-1" />
                      Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Blog Posts */}
        <div>
          <h3 className="text-3xl font-bold mb-8 text-foreground">Latest Articles</h3>
          <div className="space-y-6">
            {blogPosts.map((post, index) => (
              <Card key={post.title} className="bg-gradient-card border-primary/10 hover:shadow-purple transition-all duration-300 animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <h4 className="text-xl font-semibold mb-2 text-foreground hover:text-primary transition-colors cursor-pointer">
                        {post.title}
                      </h4>
                      <p className="text-muted-foreground mb-3">{post.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {post.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-col items-end text-sm text-muted-foreground gap-2">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {post.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {post.readTime}
                      </div>
                      <Button size="sm" variant="outline" className="mt-2">
                        Read More
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProgrammingSection;