import { useLanguage } from "@/contexts/LanguageContext";
import { translations } from "@/data/translations";

const Footer = () => {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <footer className="py-8 px-6 border-t border-border">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-muted-foreground">
          {t.footerText}
        </p>
      </div>
    </footer>
  );
};

export default Footer;