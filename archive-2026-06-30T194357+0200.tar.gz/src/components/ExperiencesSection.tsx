import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, MapPin, Calendar, Heart, Plane, Coffee, Music, Book } from "lucide-react";

const ExperiencesSection = () => {
  const experiences = [
    {
      title: "Hiking the Pacific Coast Trail",
      description: "A 10-day adventure along the stunning coastline that taught me about perseverance, nature's beauty, and the importance of unplugging from technology.",
      date: "Summer 2024",
      location: "California, USA",
      image: "🏔️",
      tags: ["Adventure", "Nature", "Photography"],
      icon: Camera
    },
    {
      title: "Learning to Play Guitar",
      description: "Started learning guitar during the pandemic. From struggling with basic chords to playing my first song - it's been a journey of patience and daily practice.",
      date: "2020 - Present",
      location: "Home Studio",
      image: "🎸",
      tags: ["Music", "Learning", "Creativity"],
      icon: Music
    },
    {
      title: "Teaching Kids to Code",
      description: "Volunteering at local schools to introduce kids to programming. Seeing their eyes light up when they create their first animated sprite is pure magic.",
      date: "2023 - Present",
      location: "Bay Area Schools",
      image: "👨‍🏫",
      tags: ["Teaching", "Community", "Impact"],
      icon: Heart
    },
    {
      title: "Coffee Shop Chronicles",
      description: "My quest to find the perfect coffee shop for remote work led me to discover 47 unique cafes across the city. Each has its own story and character.",
      date: "2022 - 2024",
      location: "San Francisco",
      image: "☕",
      tags: ["Coffee", "Remote Work", "Exploration"],
      icon: Coffee
    },
    {
      title: "Solo Travel to Japan",
      description: "Three weeks exploring Japan taught me about minimalism, respect, and how technology can enhance rather than replace human connection.",
      date: "Spring 2023",
      location: "Tokyo, Kyoto, Osaka",
      image: "🏯",
      tags: ["Travel", "Culture", "Self-Discovery"],
      icon: Plane
    },
    {
      title: "Reading 52 Books Challenge",
      description: "Committed to reading one book per week for a year. From fiction to tech books to philosophy - it completely changed how I think and learn.",
      date: "2022",
      location: "Everywhere",
      image: "📚",
      tags: ["Reading", "Growth", "Challenge"],
      icon: Book
    }
  ];

  return (
    <section className="py-20 px-6 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            Life Experiences
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Beyond the code, here are some adventures, lessons, and random moments that have shaped who I am. 
            Life's too short not to document the journey.
          </p>
        </div>

        {/* Experiences Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {experiences.map((experience, index) => (
            <Card key={experience.title} className="bg-gradient-card border-primary/10 hover:shadow-purple transition-all duration-300 hover:-translate-y-2 animate-slide-up" style={{ animationDelay: `${index * 150}ms` }}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">{experience.image}</div>
                    <div className="flex-1">
                      <CardTitle className="text-lg font-semibold text-foreground mb-2">
                        {experience.title}
                      </CardTitle>
                      <div className="flex flex-col gap-1 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {experience.date}
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {experience.location}
                        </div>
                      </div>
                    </div>
                  </div>
                  <experience.icon className="w-5 h-5 text-primary" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{experience.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {experience.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quote */}
        <div className="mt-16 text-center animate-fade-in">
          <blockquote className="text-2xl md:text-3xl font-medium text-foreground mb-4 italic">
            "Life is what happens when you're busy making other plans."
          </blockquote>
          <p className="text-muted-foreground">
            - John Lennon (and also a good reminder for developers to step away from the screen sometimes)
          </p>
        </div>
      </div>
    </section>
  );
};

export default ExperiencesSection;