import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Github, Linkedin, Mail, MapPin } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const ProfileHero = () => {
  const skills = ["React", "TypeScript", "Node.js", "Python", "UI/UX"];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      <div className="absolute inset-0 bg-gradient-hero opacity-90" />
      <div className="absolute inset-0 bg-background/10" />
      
      {/* Floating orbs */}
      <div className="absolute top-20 left-20 w-32 h-32 bg-primary-glow/20 rounded-full blur-xl animate-glow-pulse" />
      <div className="absolute bottom-20 right-20 w-24 h-24 bg-primary/30 rounded-full blur-lg animate-glow-pulse delay-1000" />
      
      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto animate-fade-in">
        <div className="mb-6">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-primary p-1 shadow-glow">
            <div className="w-full h-full rounded-full bg-card flex items-center justify-center text-6xl font-bold text-primary">
              V
            </div>
          </div>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
          NYX Developer
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground mb-6 max-w-2xl mx-auto">
          Full-Stack Developer & Digital Storyteller
        </p>
        
        <div className="flex items-center justify-center gap-2 mb-8 text-muted-foreground">
          <MapPin className="w-4 h-4" />
          <span>San Francisco, CA</span>
        </div>
        
        {/* Skills */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {skills.map((skill) => (
            <Badge 
              key={skill} 
              variant="secondary" 
              className="bg-card/80 text-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300 shadow-purple"
            >
              {skill}
            </Badge>
          ))}
        </div>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Button size="lg" className="bg-primary hover:bg-primary/90 shadow-glow">
            <Mail className="w-4 h-4 mr-2" />
            Get In Touch
          </Button>
          <Button variant="outline" size="lg" className="border-primary/20 hover:bg-primary/10">
            View My Work
          </Button>
        </div>
        
        {/* Social Links */}
        <div className="flex justify-center gap-6">
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
            <Github className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
            <Linkedin className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
            <Mail className="w-5 h-5" />
          </Button>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default ProfileHero;